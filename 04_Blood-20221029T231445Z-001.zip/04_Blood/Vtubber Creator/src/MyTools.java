import java.io.IOException;

public class MyTools {
    public MyTools() {
    }

    

    public static void bar() {
        String bar = "--------------------";
        System.out.println(bar);
    }

    public static String space() {
        String spc = " ";
        return spc;
    }

    public static void clean() {
        try {
            if (System.getProperty("os.name").contains("Windows"))
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
                Runtime.getRuntime().exec("clear");
        } catch (IOException | InterruptedException ex) {
        }
    }
}
