import java.util.Scanner;

public class Vtubber {
    private String name;
    private int age;
    private char sex;
    private String region;
    private String channel;
    private int subs;

    public void sing() {
    }

    public void draw() {
    }

    public void cook() {
    }

    public void readSuperChat() {
    }

    public void play() {
    }

    public void doCollab() {
    }

    Vtubber() {
    }

    public Vtubber(String name, int age, char sex, String region, String channel, int subs) {
        this.name = name;
        this.age = age;
        this.sex = sex;
        this.region = region;
        this.channel = channel;
        this.subs = subs;
    }

    public void readAll() {
        readName();
        readAge();
        readSex();
        readRegion();
        readChannel();
        readSubs();
        MyTools.clean();
    }

    public void showAll() {
        System.out.println("Vtubber name:\t" + getName());
        System.out.println("Age:\t" + getAge());
        System.out.println("Sex:\t" + getSex());
        System.out.println("Country:\t" + getRegion());
        System.out.println("Channel:\tyoutube.com/" + getChannel());
        System.out.println("Subs:\t" + getSubs());
    }

    
    public void readName() {
        System.out.println("Name:");
        Scanner name = new Scanner(System.in);
        setName(name.nextLine());
    }

    public void readAge() {
        System.out.println("Age:");
        Scanner age = new Scanner(System.in);
        setAge(age.nextInt());
    }

    public void readSex() {
        System.out.println("Sex:\tM -- Man   W -- Woman");
        Scanner sex = new Scanner(System.in);
        setSex(sex.next().charAt(0));
    }

    public void readChannel() {
        System.out.println("Channel:");
        Scanner channel = new Scanner(System.in);
        setChannel(channel.nextLine());
    }

    public void readRegion() {
        System.out.println("Country:");
        Scanner region = new Scanner(System.in);
        setRegion(region.nextLine());
    }

    public void readSubs() {
        System.out.println("Subs:");
        Scanner subs = new Scanner(System.in);
        setSubs(subs.nextInt());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public int getSubs() {
        return subs;
    }

    public void setSubs(int subs) {
        this.subs = subs;
    }
}
