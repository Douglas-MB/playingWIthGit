public class Main {
    public static void main(String[] args) throws Exception {
        MyTools.clean();
        // Vtubber obj = new Vtubber();
        Vtubber member0 = new Vtubber();
        member0.readAll();
        member0.showAll();
    }
}
