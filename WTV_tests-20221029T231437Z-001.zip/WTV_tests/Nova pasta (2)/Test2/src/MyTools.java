import java.util.Scanner;

public interface MyTools {
        public abstract Scanner scan();
        
}