import java.util.Scanner;

public abstract class Tools implements MyTools {
    public Scanner scan(){
        return new Scanner(System.in);
    }
    
}
