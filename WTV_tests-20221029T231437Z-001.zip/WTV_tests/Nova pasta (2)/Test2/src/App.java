import java.util.Scanner;

public class App implements MyTools{
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
    }

    @Override
    public Scanner scan() {
        // TODO Auto-generated method stub
        return null;
    }
}
