import java.util.Scanner;

public class App extends MyTools {
    public static void main(String[] args) throws Exception {
        MyTools.clean();
        MyTools.bar();






    }
}
