import java.util.Scanner;

public class Teste {

    public static void main(String[] args) {
        
        int opcao;
        System.out.println("Cadastro de Eventos:");
        
        Scanner read = new Scanner(System.in);
        
        System.out.println("Selecione o tipo de Evento que gostaria de cadastrar: \n 1 - Formatura \n 2 - Palestra");
        opcao = read.nextInt();
        read.nextLine();
       
        switch (opcao) {
            case 1:
                System.out.println("Cadastro de formatura:");
                
                System.out.println("Informe o nome da formatura: ");
                String nome = read.nextLine();
                
                System.out.println("Informe o horário de início: ");
                String horaIn = read.nextLine();
                
                System.out.println("Informe a quantidade de vagas para convidados: ");
                int qtVagas = read.nextInt();
                read.nextLine();
                
                System.out.println("Informe o Orador: ");
                String orador = read.nextLine();
                
                System.out.println("Informe o Curso: ");
                String curso = read.nextLine();
                
                
                System.out.println("Informe o número de formandos: ");
                int numFormandos = read.nextInt();
                read.nextLine();
                
                System.out.println("Informe o Professor Homenageado: ");
                String prof = read.nextLine();
                
                Formatura formatura = new Formatura(orador, curso, numFormandos, prof, nome, horaIn, true, qtVagas);
               
                
                formatura.exibeDados();
                formatura.verficaVagas(formatura.getNumFormandos());
                 break;
            case 2:
                System.out.println("Cadastro de Palestra:");
                
                System.out.println("Informe o nome da Palestra: ");
                String nomePalestra = read.nextLine();
                
                System.out.println("Informe o horário de início: ");
                String horaIni = read.nextLine();
                
                System.out.println("Aberta ao público: ");
                String auxType = read.nextLine();
                boolean palestraPrivada = false;
                
                if(auxType.toUpperCase() == "SIM" ||  auxType.toUpperCase() == "S" ) {
                    palestraPrivada = true;
                }
                
                if(auxType.toUpperCase() == "NAO" ||  auxType.toUpperCase() == "N" ) {
                    palestraPrivada = false;
                }
                
                System.out.println("Informe a quantidade de vagas para convidados: ");
                int qtVagasPalestra = read.nextInt();
                read.nextLine();
                
                System.out.println("Informe o Palestrante: ");
                String palestrante = read.nextLine();
                
                System.out.println("Informe o Tema: ");
                String tema = read.nextLine();
                
                
                System.out.println("Informe a duração da palestra: ");
                int duracao = read.nextInt();
                
                
                Palestra palestra = new Palestra(palestrante, tema, duracao, nomePalestra, horaIni, palestraPrivada, qtVagasPalestra);
               
                
                palestra.exibeDados();
                palestra.verficaVagas();
                break;
            default:
                System.err.println("Opção inexistente");
        }
    }
}