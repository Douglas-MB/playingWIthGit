public class Formatura extends EventoAcademico {
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private String orador;
    private String curso;
    private int numFormandos;
    private String profHomenageado; 
    
    /**
     * Construtor para objetos da classe Formatura
     */
    
    
    public Formatura(String orador, String curso, int numFormandos, String profHomenageado, String nomeEvento, String horaInicio, boolean eventoPrivado, int qtVagas) {
        super(nomeEvento, horaInicio, eventoPrivado, qtVagas);
        this.orador = orador;
        this.curso = curso;
        this.numFormandos = numFormandos;
        this.profHomenageado = profHomenageado;
    }

    public String getOrador() {
        return orador;
    }

    public void setOrador(String orador) {
        this.orador = orador;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public int getNumFormandos() {
        return numFormandos;
    }

    public void setNumFormandos(int numFormandos) {
        this.numFormandos = numFormandos;
    }

    public String getProfHomenageado() {
        return profHomenageado;
    }

    public void setProfHomenageado(String profHomenageado) {
        this.profHomenageado = profHomenageado;
    }

    public void exibeDados() {
        System.out.println("Evento de Formatura");
        super.exibeDados();
        System.out.println("Curso: " + curso );
        System.out.println("Número de formandos: " + numFormandos);
        System.out.println("Orador: " + orador);
        System.out.println("Professor Homenageado: " + profHomenageado);
    }
    
    public void verficaVagas(int nFormandos) {
        super.verficaVagas();
        int qtConvites = super.getQtVagas() / nFormandos;
        System.out.printf("Para cada formando terá a quantidade disponível de ingresso: %d",qtConvites);
        
    }
}