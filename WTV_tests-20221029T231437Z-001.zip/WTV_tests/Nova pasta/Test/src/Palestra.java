public class Palestra extends EventoAcademico {

    private String palestrante;
    private String tema;
    private int duracao;

    public Palestra(String palestrante, String tema, int duracao, String nomeEvento, String horaInicio, boolean eventoPrivado, int qtVagas) {
        super(nomeEvento, horaInicio, eventoPrivado, qtVagas);
        this.palestrante = palestrante;
        this.tema = tema;
        this.duracao = duracao;
    }

    public String getPalestrante() {
        return palestrante;
    }

    public void setPalestrante(String palestrante) {
        this.palestrante = palestrante;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public void exibeDados() {
        System.out.println("Palestra");
        super.exibeDados();
        System.out.println("Palestrante: " + palestrante);
        System.out.println("Tema da palestra: " + tema);
        System.out.println("Duração da palestra: " + duracao);
       
    }
    
      public void verficaVagas() {
        System.out.println("Verificação de vagas da Palestra:");
        super.verficaVagas();
        
    }
}