
public abstract class EventoAcademico {
    // Atributos comuns para todos os eventos

    private String nomeEvento;
    private String horaInicio;
    private boolean eventoPrivado;
    private int qtVagas;

    // Construtor
    public EventoAcademico(String nomeEvento, String horaInicio, boolean eventoPrivado, int qtVagas) {
        this.nomeEvento = nomeEvento;
        this.horaInicio = horaInicio;
        this.eventoPrivado = eventoPrivado;
        this.qtVagas = qtVagas;

    }

    // Métodos get
    public String getNomeEvento() {
        return nomeEvento;
    }

    public String gethoraInicio() {
        return horaInicio;
    }

    public boolean getEventoPrivado() {
        return eventoPrivado;
    }

    public int getQtVagas() {
        return qtVagas;
    }

    // Métodos Set
    public void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }

    public void sethoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public void setEventoPrivado(boolean eventoPrivado) {
        this.eventoPrivado = eventoPrivado;
    }

    public void setQtVagas(int qtVagas) {
        this.qtVagas = qtVagas;
    }

    //Exibição dos dados
    public void exibeDados() {
        System.out.println("Nome Evento: " + nomeEvento);
        System.out.println("Hora de Início do Evento: " + horaInicio);
        String auxEvtType = "";
        if(eventoPrivado == false) {
            auxEvtType = "Não";
        }else{  
            auxEvtType = "Sim";
        }
        System.out.println("Evento Privado: " + auxEvtType);
        System.out.println("Quantidade de vagas: " + qtVagas);
    }

    public void verificarVagas() {
        System.out.println("A quantidade de vagas disponíveis para esse evento é de: " + qtVagas);
    }

    //Método de diminuição de vagas
    public void diminuiVaga() {
        this.qtVagas--;
    }

    //Método de edição do nome do Evento
    public void alteraNomeEvento(String novoNomeEvento) {
        this.nomeEvento = novoNomeEvento;
    }

    public void verficaVagas() {
        System.out.println("Quantidade de vagas disponíveis para o Evento: " + qtVagas);
    }

    public void verificaDisponibilidadeEventoPublico() {
        if (!getEventoPrivado()) {
            if (getQtVagas() == 0) {
                System.out.println("O Evento: " + getNomeEvento() + " Está Esgotado");
            } else {
                String msg = (getQtVagas() > 1) ? "vagas disponíveis" : "vaga disponível";
                System.out.println("O Evento: " + getNomeEvento() + " Está com " + getQtVagas() + " " + msg);
            }
        } else {
            System.out.println("Não existem eventos públicos disponíveis");
        }
    }

}

 