import java.io.IOException;


public class App {
    public static void main(String[] args) throws Exception {
        String spc = " ";
        int cnt1 = 1;
        try {
            if (System.getProperty("os.name").contains("Windows"))
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
                Runtime.getRuntime().exec("clear");
        } catch (IOException | InterruptedException ex) {}
        
        HoloWarrior char1 = new HoloWarrior("Unknown",1000, 100, 10, 1);
        //char1.show();
        
        char1.setName("Suisei");
        //char1.setAttack(999);
        char1.setHeathPoints(9999);
        char1.setAttack(999);
        char1.setLevel(99);
        char1.setResistence(999);
        char1.show();
        
        System.out.println(char1.getBarHif());

        while(char1.getHeathPoints()>0){
            char1.setHeathPoints(char1.getHeathPoints()-char1.formulaGeneral());
            if(char1.getHeathPoints()>0){
            System.out.println("Current HP:\t"+char1.getHeathPoints());
            }else{
                System.out.println("Current HP:\t0");
            }
            Thread.sleep(500);
        }
        /*int bigHit=0;
        int bigHitAux = 0;

            while(cnt1<100+1){
                //char1.atk();
                int aux = char1.atk();
                if(aux>bigHit){
                    //char1.atk();
                    bigHit = aux;
                    System.out.print(cnt1+spc+"Hit value"+spc+bigHit+"!!!!!\n");
                    //bigHitAux = char1.atk();
                }else {
                    System.out.print(cnt1+spc+"Hit value"+spc+aux
                    +"\n");
                }

                if(bigHit>bigHitAux){
                    bigHitAux = bigHit;
                }

                
                Thread.sleep(500);
                cnt1++;
            }
            System.out.print("**********THE LARGEST HIT VALUE IS "+bigHitAux+"**********\n\n\n");
        */
    }
}
