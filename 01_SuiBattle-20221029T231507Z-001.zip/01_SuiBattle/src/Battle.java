public class Battle {

    
    public Battle() {
        HoloWarrior.formulaGeneral();
    }

    public void winLose(){}

}
