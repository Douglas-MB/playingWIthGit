import java.lang.Math;


public class HoloWarrior { //to use interface
    private String name;
    private int heathPoints;
    private int attack;
    private int resistence;
    private int level;
    private String bar = "--------------";

    
    public HoloWarrior(String name, int heathPoints, int attack, int resistence, int level) {
        this.name = name;
        this.heathPoints = heathPoints;
        this.attack = attack;
        this.resistence = resistence;
        this.level = level;
    }

    public int formulaGeneral(){
        int dmTkn = atk() - res();
        if(dmTkn<0){
            dmTkn = -dmTkn;
        }
        return dmTkn;
    }

    public int res(){
        int resP = atk()/2;
        return resP;
    }

    public double numSeed(){
        double num = (Math.random());
        if(num<0.1){
            num =num +0.1;
        }
        if(num>0.99){
            Math.round(num);
        }
        return num;
    }
    public int atk(){
        int dmgHit = (int)((getAttack())*(numSeed()));
       
        return dmgHit;
    }
    public void show(){
        System.out.println(getName().toUpperCase()+"\n"+bar);
        System.out.println("LV:\t"+getLevel());
        System.out.println("HP:\t"+getHeathPoints());
        System.out.println("ATK:\t"+getAttack());
        System.out.println("RES:\t"+getResistence());



    }
    public String getBarHif(){
        String bar = "--------------";
        return bar;
    }   
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getHeathPoints() {
        return heathPoints;
    }
    public void setHeathPoints(int heathPoints) {
        this.heathPoints = heathPoints;
    }
    public int getAttack() {
        return attack;
    }
    public void setAttack(int attack) {
        this.attack = attack;
    }
    public int getResistence() {
        return resistence;
    }
    public void setResistence(int resistence) {
        this.resistence = resistence;
    }
    public int getLevel() {
        return level;
    }
    public void setLevel(int level) {
        this.level = level;
    }
    

    
    

    
}
