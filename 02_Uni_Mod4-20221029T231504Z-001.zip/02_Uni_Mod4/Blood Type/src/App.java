import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.print("Teste\n");
        /*person1.setName(person1.readNome());
        person1.setBloodType(person1.readBlood());
        person1.show();*/

        ArrayList<Blood> person = new ArrayList<Blood>();
        Scanner auxR = new Scanner(System.in);
        
        String auxB = auxR.nextLine();
        int auxA = Integer.parseInt(auxB);
        for(int aux = 0; aux<auxA;aux++){
            //auxR.nextLine();
            person.add(new Blood(Blood.readNome(), Blood.readBlood()));
            Others screen = new Others();
            screen.Clean();
        }
        Others.bar();
        
        ArrayList<Blood> list = new ArrayList<Blood>();

        list.add(new Blood("Rainha Elizabeth II", "O"));
        list.add(new Blood("John Lennon", "O"));
        list.add(new Blood("Britney Spears", "A"));
        list.add(new Blood("Jet Li", "A"));
        list.add(new Blood("Paul McCartney", "B"));
        list.add(new Blood("Leonardo Dicaprio", "B"));
        list.add(new Blood("Jackie Chan", "AB"));
        list.add(new Blood("Marilyn Monroe", "AB"));

        /*for(Blood pessoa: person){
            System.out.println("Pessoa"+Others.space()+ pessoa.toString());
        } */       
        //System.out.println("Tipo: "+person.get(0).getBloodType());

    }
}
