import java.io.IOException;

public class Others {
    public Others() {
    }

    public void Clean(){
        try {
            if (System.getProperty("os.name").contains("Windows"))
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
                Runtime.getRuntime().exec("clear");
        } catch (IOException | InterruptedException ex) {}
    }

    public static String space(){
        return " ";
    }

    public static String bar(){
        return "-------------------";
    }
}
