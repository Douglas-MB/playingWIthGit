import java.util.Scanner;

public class Blood {
        String name;
        String bloodType;
        //int idade;
        //String bday;
        //String spc = " ";

        Blood(){}
        public Blood(String name, String bloodType) {
            this.name = name;
            this.bloodType = bloodType;
        }

        public static String readNome(){
            System.out.print("Por favor, informe o seu nome :)\n");
            Scanner nome = new Scanner(System.in);
            String nomeR = nome.nextLine();
            return nomeR;
        }

        public static String readBlood(){
            System.out.print("Por favor, informe o seu tipo sanguíneo :)\n");
            Scanner sangue = new Scanner(System.in);
            String sangueR = sangue.nextLine();
            return sangueR;
        }

        public void show(){
            System.out.println("Seu nome:\t"+getName());
            System.out.println("Seu tipo sanguíneo:\t"+getBloodType());
        }

        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public String getBloodType() {
            return bloodType;
        }
        public void setBloodType(String bloodType) {
            this.bloodType = bloodType;
        }
        @Override
        public String toString() {
            return "Nome:" + Others.space() + getName()+ "\t"+"Tipo sanguíneo:"+Others.space()+getBloodType()+"\n";
        }
}
