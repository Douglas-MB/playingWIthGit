import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        MyTools.clean();

        Numbers obj = new Numbers();
        Scanner read = new Scanner(System.in);
        String auxWord = "Y";
        System.out.println("Select a option to do some operation");
        int aux = read.nextInt();
        int cnt = 0;

        MyTools.bar();

        while (aux > 0) {
            switch (aux) {
                case 1:
                    obj.readArraySize();
                    obj.operation1();
                    break;
                case 2:
                    obj.readArraySize();
                    obj.operation2();
                    break;
            }
            System.out.println("Do u wanna to continue to do stupid things?\n\tY -- Yes\tN -- No");
            auxWord = read.nextLine();
            auxWord = read.nextLine().toUpperCase();
            if (auxWord == "Y") {
                for (int auxDot = 0; auxDot < 4; auxDot++) {
                    System.out.print(". ");
                    Thread.sleep(450);
                }
                System.out.println("\nU do have a mental problem...");
                Thread.sleep(350);
                continue;
            } else if (auxWord != "Y" || auxWord != "N") {
                System.out.println("Y or N, do u know to read?");

                while (auxWord != "Y" || auxWord != "N") {

                    auxWord = read.nextLine().toUpperCase();
                    System.out.println("Y or N, do u know to read?");
                    cnt++;
                    if (cnt > 5) {
                        System.out.println("AAAAAAAAAAAAAAAAAAAAAA U ARE SO...");
                        Thread.sleep(300);
                        System.out.println("\tDUMMY!!!\n\t\t\t\tBYE!");
                        break;
                    }

                }
                break;
            } else {
                System.out.println("That was a wise decision, friend");
                break;
            }
        }
    }
}
