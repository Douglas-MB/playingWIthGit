import java.util.ArrayList;
import java.util.Scanner;

public class Cake extends Candy {
    Scanner cakeType = MyTools.scan();

    public Cake(String name, double price, int quantity) {
        super(name, price, quantity);
    }

    @Override
    public void makeCandy() {
        System.out.println("Choose 0 to check the menu :)");
        
        switch (cakeType.nextInt()) {
            case 0:
                ArrayList<String> cakeOptions= new ArrayList<String>();
                cakeOptions.add("1 --> Chocolate");
                cakeOptions.add("2 --> Strawberry");
                cakeOptions.add("3 --> Pineapple");
                for(int aux =0; aux<cakeOptions.size();aux++){
                    System.out.println(cakeOptions.get(aux));
                }
                break;
            case 1:
                setName("Chocolate Cake");
                setPrice(4.32);
                showCake();
                break;
            case 2:
                setName("Strawberry Cake");
                setPrice(6.75);

                showCake();
                break;

            case 3:
                setName("Pineapple Cake");
                setPrice(8.11);

                showCake();
                break;

        }

    }

    public void showCake() {
        System.out.println("Cake Type:\t" + getName());
        System.out.printf("Cake Price:\t" + "$ %.2f", getPrice());
        System.out.println("\nQuantity:\t" + getQuantity());

    }

    @Override
    public void saleCandy() {

    }

    @Override
    public int eatCandy() {
        return quantity = getQuantity()-1;
    }

}
