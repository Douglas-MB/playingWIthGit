import java.util.Scanner;

public class Bakery {
    public static void main(String[] args) throws Exception {
        MyTools.clean();
        Scanner auxRead = MyTools.scan();

        System.out.print("What is ur name?\t");
        String customer = auxRead.nextLine();
        System.out.print("How much money?\t");
        double customerMoney = auxRead.nextDouble();

        
        Cake cake0 = new Cake(customer, customerMoney, 5);
        cake0.makeCandy();
        cake0.eatCandy();
    }
}
